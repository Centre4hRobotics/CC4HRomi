#pragma once

void __initializeGyro();

void __resetGyro();

double __getGyroAngle();

void __integrate();